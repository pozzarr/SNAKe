import java.awt.Point;
import java.util.Random;

public class Food {
    private Point position;
    private Random random;
    private int gridWidth;  // Ширина игрового поля в клетках
    private int gridHeight; // Высота игрового поля в клетках

    /**
     * Конструктор создаёт еду и сразу размещает её на поле.
     * @param gridWidth  Ширина поля (например, 30)
     * @param gridHeight Высота поля (например, 28)
     */
    public Food(int gridWidth, int gridHeight) {
        if (gridWidth <= 0 || gridHeight <= 0) {
            throw new IllegalArgumentException("Размеры поля должны быть положительными!");
        }

        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.random = new Random();

        respawn();
    }

    public void respawn() {
        int x = random.nextInt(gridWidth);
        int y = random.nextInt(gridHeight);

        x = Math.max(0, Math.min(x, gridWidth - 1));
        y = Math.max(0, Math.min(y, gridHeight - 1));

        position = new Point(x, y);
    }
    public Point getPosition() {
        return position;
    }

    public void setPosition(Point pos) {

        this.position = pos;
    }

    public int getGridWidth() { return gridWidth; }
    public int getGridHeight() { return gridHeight; }
}