import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class Game {
    private Snake snake;
    private Food food;
    private GameState currentState;
    private Timer timer;
    private GamePanel panel;
    private Table highScoreTable;

    private boolean isGameOver = false;
    private static final int GAME_SPEED = 150;

    public Game() {
        this.highScoreTable = new Table();
        init();
        startTimer();
    }

    private void init() {
        snake = new Snake();

        int gw = (panel != null) ? panel.getGridWidth() : 30;
        int gh = (panel != null) ? panel.getGridHeight() : 28;

        food = new Food(gw, gh);

        if (panel == null) {
            panel = new GamePanel(this, highScoreTable);
        } else {
            panel.repaint();
        }

        currentState = new GameState();
        updateGameState();
        isGameOver = false;
    }

    private void startTimer() {
        if (timer != null) {
            timer.stop();
        }

        timer = new Timer(GAME_SPEED, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isGameOver) {
                    snake.move();
                    checkCollisions();
                    updateGameState();
                    panel.repaint();
                }
            }
        });
        timer.start();
    }

    private void checkCollisions() {
        int gridW = panel.getGridWidth();
        int gridH = panel.getGridHeight();

        if (snake.checkCollisionWithWall(gridW, gridH) || snake.checkCollisionWithSelf()) {
            isGameOver = true;
            timer.stop();

            highScoreTable.addScore(snake.getScore());

            JOptionPane.showMessageDialog(panel,
                    "Game Over! Ваш счёт: " + snake.getScore(),
                    "Конец игры",
                    JOptionPane.INFORMATION_MESSAGE);

            restartGameLogic();

            return;
        }

        if (snake.getHead().equals(food.getPosition())) {
            snake.grow();
            food.respawn();
        }
    }

    public void restartGameLogic() {
        init();
        startTimer();

        SwingUtilities.invokeLater(() -> {
            panel.requestFocusInWindow();
            panel.repaint();
        });
    }

    public void handleKeyInput(KeyEvent e) {
        if (isGameOver) return;

        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:    snake.setDirection(Direction.UP); break;
            case KeyEvent.VK_DOWN:  snake.setDirection(Direction.DOWN); break;
            case KeyEvent.VK_LEFT:  snake.setDirection(Direction.LEFT); break;
            case KeyEvent.VK_RIGHT: snake.setDirection(Direction.RIGHT); break;
            case KeyEvent.VK_S:     saveCurrentState(); break;
            case KeyEvent.VK_L:     loadSavedState(); break;
        }
    }

    private void saveCurrentState() {
        try {
            Save.saveGame(currentState);
            JOptionPane.showMessageDialog(panel, "Игра успешно сохранена!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(panel, "Ошибка при сохранении!", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadSavedState() {
        try {
            GameState loadedState = Save.loadGame();

            snake.restoreFromState(loadedState);
            food.setPosition(loadedState.getFoodPosition());

            isGameOver = loadedState.isGameOver();

            if (isGameOver) {
                timer.stop();
            } else {
                startTimer();
            }

            panel.repaint();
            JOptionPane.showMessageDialog(panel, "Игра загружена!");

            SwingUtilities.invokeLater(() -> panel.requestFocusInWindow());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(panel, "Нет сохранения или ошибка файла.", "Ошибка", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void updateGameState() {
        currentState.setSnakeBody(snake.getBody());
        currentState.setFoodPosition(food.getPosition());
        currentState.setDirection(snake.getDirection());
        currentState.setScore(snake.getScore());
        currentState.setGameOver(isGameOver);
    }

    public Snake getSnake() { return snake; }
    public Food getFood() { return food; }
    public boolean isGameOver() { return isGameOver; }
    public GamePanel getPanel() { return panel; }
    public Table getHighScoreTable() { return highScoreTable; }
}