import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class GamePanel extends JPanel {
    private static final int CELL_SIZE = 30;
    private static final int GRID_WIDTH = 30;
    private static final int GRID_HEIGHT = 26;
    private static final int WIDTH = GRID_WIDTH * CELL_SIZE;   // 900 px
    private static final int HEIGHT = GRID_HEIGHT * CELL_SIZE; // 840 px

    private Game game;
    private Table highScoreTable;

    private BufferedImage snakeHead;
    private BufferedImage snakeBody;
    private BufferedImage foodImage;
    private BufferedImage backgroundImage;

    private static final Color HEAD_COLOR = Color.GREEN;
    private static final Color BODY_COLOR = new Color(144, 238, 144);
    private static final Color FOOD_COLOR = Color.RED;
    private static final Color TEXT_COLOR = Color.BLACK;

    public GamePanel(Game game, Table highScoreTable) {
        this.game = game;
        this.highScoreTable = highScoreTable;

        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);

        loadImages();
        setupControls();
    }

    private void loadImages() {
        try {
            snakeHead = ImageIO.read(new File("Image/snake_head.png"));
            snakeBody = ImageIO.read(new File("Image/snake_body.png"));
            foodImage = ImageIO.read(new File("Image/food.png"));

            backgroundImage = ImageIO.read(new File("Image/land.png"));

            System.out.println("Все картинки успешно загружены!");

        } catch (IOException e) {
            System.err.println(" Ошибка загрузки картинок!");

            snakeHead = null;
            snakeBody = null;
            foodImage = null;
            backgroundImage = null;

            setBackground(new Color(25, 25, 35));
        }
    }

    private void setupControls() {
        InputMap inputMap = this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = this.getActionMap();

        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "moveUp");
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "moveDown");
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "moveLeft");
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "moveRight");
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0), "saveGame");
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_L, 0), "loadGame");

        actionMap.put("moveUp", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_UP, ' '));
            }
        });
        actionMap.put("moveDown", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_DOWN, ' '));
            }
        });
        actionMap.put("moveLeft", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_LEFT, ' '));
            }
        });
        actionMap.put("moveRight", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_RIGHT, ' '));
            }
        });
        actionMap.put("saveGame", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_S, 's'));
            }
        });
        actionMap.put("loadGame", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game != null) game.handleKeyInput(new KeyEvent(GamePanel.this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_L, 'l'));
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (backgroundImage != null) {
            g2d.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, null);
        } else {
            g2d.setColor(getBackground());
            g2d.fillRect(0, 0, WIDTH, HEIGHT);
        }

        if (game.getSnake() == null) return;

        Snake snake = game.getSnake();
        List<Point> body = snake.getBody();

        for (int i = 0; i < body.size(); i++) {
            Point p = body.get(i);
            int x = p.x * CELL_SIZE;
            int y = p.y * CELL_SIZE;

            if (i == 0) {
                drawImageOrRect(g2d, snakeHead, HEAD_COLOR, x, y);
            } else {
                drawImageOrRect(g2d, snakeBody, BODY_COLOR, x, y);
            }
        }

        if (game.getFood() != null) {
            Food food = game.getFood();
            Point foodPos = food.getPosition();
            int fx = foodPos.x * CELL_SIZE;
            int fy = foodPos.y * CELL_SIZE;

            if (foodImage != null) {
                g2d.drawImage(foodImage, fx, fy, CELL_SIZE, CELL_SIZE, null);
            } else {
                g2d.setColor(FOOD_COLOR);
                g2d.fillOval(fx + 4, fy + 4, CELL_SIZE - 8, CELL_SIZE - 8);
            }
        }

        g2d.setColor(TEXT_COLOR);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));
        g2d.drawString("Счёт: " + snake.getScore(), 20, 30);

        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        g2d.drawString("Рекорды:", 20, HEIGHT - 120);

        List<Integer> scores = highScoreTable.getScores();
        int yStart = HEIGHT - 100;

        if (scores.isEmpty()) {
            g2d.setFont(new Font("Arial", Font.PLAIN, 14));
            g2d.drawString("Пока нет рекордов", 20, yStart);
        } else {
            for (int i = 0; i < scores.size(); i++) {
                g2d.drawString((i + 1) + ". " + scores.get(i), 20, yStart + (i * 20));
            }
        }

        if (game.isGameOver()) {
            g2d.setColor(new Color(0, 0, 0, 150));
            g2d.fillRect(0, 0, WIDTH, HEIGHT);

            g2d.setColor(Color.RED);
            g2d.setFont(new Font("Arial", Font.BOLD, 40));
            String gameOverText = "GAME OVER";
            int textWidth = g2d.getFontMetrics().stringWidth(gameOverText);
            g2d.drawString(gameOverText, (WIDTH - textWidth) / 2, HEIGHT / 2);

            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.PLAIN, 20));
            String restartText = "Нажмите OK для рестарта";
            int restartWidth = g2d.getFontMetrics().stringWidth(restartText);
            g2d.drawString(restartText, (WIDTH - restartWidth) / 2, HEIGHT / 2 + 40);
        }
    }

    private void drawImageOrRect(Graphics2D g2d, BufferedImage img, Color color, int x, int y) {
        if (img != null) {
            g2d.drawImage(img, x, y, CELL_SIZE, CELL_SIZE, null);
        } else {
            g2d.setColor(color);
            g2d.fillRect(x + 1, y + 1, CELL_SIZE - 2, CELL_SIZE - 2);
        }
    }

    public int getGridWidth() { return GRID_WIDTH; }
    public int getGridHeight() { return GRID_HEIGHT; }
}