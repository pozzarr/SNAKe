import java.io.Serializable;
import java.util.List;
import java.awt.Point;

public class GameState implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Point> snakeBody;
    private Point foodPosition;
    private Direction direction;
    private int score;
    private boolean isGameOver;

    public GameState() {}

    public List<Point> getSnakeBody() { return snakeBody; }
    public void setSnakeBody(List<Point> snakeBody) { this.snakeBody = snakeBody; }

    public Point getFoodPosition() { return foodPosition; }
    public void setFoodPosition(Point foodPosition) { this.foodPosition = foodPosition; }

    public Direction getDirection() { return direction; }
    public void setDirection(Direction direction) { this.direction = direction; }

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    public boolean isGameOver() { return isGameOver; }
    public void setGameOver(boolean gameOver) { isGameOver = gameOver; }
}