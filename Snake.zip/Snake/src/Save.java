import java.io.*;

public class Save {
    private static final String SAVE_FILE = "save.dat";

    public static void saveGame(GameState state) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SAVE_FILE))) {
            oos.writeObject(state);
        }
    }

    public static GameState loadGame() throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(SAVE_FILE))) {
            return (GameState) ois.readObject();
        }
    }
}