import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Snake {
    private List<Point> body;
    private Direction direction;
    private int score;

    public Snake() {
        body = new ArrayList<>();
        body.add(new Point(15, 15));
        body.add(new Point(14, 15));
        body.add(new Point(13, 15));

        direction = Direction.RIGHT;
        score = 0;
    }

    public void move() {
        Point head = body.get(0);
        Point newHead = new Point(head.x, head.y);

        switch (direction) {
            case UP:    newHead.y--; break;
            case DOWN:  newHead.y++; break;
            case LEFT:  newHead.x--; break;
            case RIGHT: newHead.x++; break;
        }

        body.add(0, newHead);
        body.remove(body.size() - 1);
    }

    public void grow() {
        Point tail = body.get(body.size() - 1);
        body.add(new Point(tail.x, tail.y));
        score += 10;
    }

    public boolean checkCollisionWithWall(int width, int height) {
        Point head = body.get(0);
        return head.x < 0 || head.x >= width || head.y < 0 || head.y >= height;
    }

    public boolean checkCollisionWithSelf() {
        Point head = body.get(0);
        for (int i = 1; i < body.size(); i++) {
            if (body.get(i).equals(head)) {
                return true;
            }
        }
        return false;
    }

    public void setDirection(Direction dir) {
        if ((dir == Direction.UP && direction != Direction.DOWN) ||
                (dir == Direction.DOWN && direction != Direction.UP) ||
                (dir == Direction.LEFT && direction != Direction.RIGHT) ||
                (dir == Direction.RIGHT && direction != Direction.LEFT)) {
            direction = dir;
        }
    }

    public Point getHead() { return body.get(0); }
    public List<Point> getBody() { return body; }
    public Direction getDirection() { return direction; }
    public int getScore() { return score; }

    public void restoreFromState(GameState state) {
        this.body = new ArrayList<>(state.getSnakeBody());
        this.direction = state.getDirection();
        this.score = state.getScore();
    }
}