import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Table {
    private static final String FILE_NAME = "table.txt";
    private List<Integer> scores;
    private static final int MAX_SCORES = 5;

    public Table() {
        this.scores = new ArrayList<>();
        loadScores();
    }

    public boolean addScore(int newScore) {
        scores.add(newScore);
        Collections.sort(scores, Collections.reverseOrder());

        if (scores.size() > MAX_SCORES) {
            scores = scores.subList(0, MAX_SCORES);
        }

        saveScores();
        return true;
    }

    public List<Integer> getScores() {
        return new ArrayList<>(scores);
    }

    private void loadScores() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    scores.add(Integer.parseInt(line.trim()));
                } catch (NumberFormatException e) {
                }
            }
            Collections.sort(scores, Collections.reverseOrder());
            if (scores.size() > MAX_SCORES) {
                scores = scores.subList(0, MAX_SCORES);
            }
        } catch (IOException e) {
            System.err.println("Ошибка чтения таблицы рекордов: " + e.getMessage());
        }
    }

    private void saveScores() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (int score : scores) {
                pw.println(score);
            }
        } catch (IOException e) {
            System.err.println("Ошибка сохранения таблицы рекордов: " + e.getMessage());
        }
    }

    public void clear() {
        scores.clear();
        saveScores();
    }
}